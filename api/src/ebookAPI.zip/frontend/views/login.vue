<template>
<div>{{ message }} page</div>
</template>
<script>
module.exports = {
  data: {
    message: 'login'
  }
};
</script>