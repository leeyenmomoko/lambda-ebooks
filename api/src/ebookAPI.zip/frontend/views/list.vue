<template>
<div>{{ message }}list</div>
</template>
<script>
module.exports = {
  data: function(){
    return {
      message: 'test'
    };
  }
};
</script>